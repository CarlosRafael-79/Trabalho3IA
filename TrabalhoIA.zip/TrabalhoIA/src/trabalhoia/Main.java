
public class Main {

    public static void main(String[] args) {
        RedesNeurais rn = new RedesNeurais();
        rn.buildDecisionTree();
    }
}